2: 376

3:
{
            "Title": "Hunger",
            "Year": "2023",
            "imdbID": "tt22695402",
            "Type": "movie",
            "Poster": "https://m.media-amazon.com/images/M/MV5BODQ2ZDVhY2ItMTcwYS00ZDUzLTlhMDctYjhmMWVkODUzYzU4XkEyXkFqcGc@._V1_SX300.jpg"
        }

4: 
"imdbVotes": "1,017,055",
"Actors": "Billy Crystal, John Goodman, Mary Gibbs",
"Poster": "https://m.media-amazon.com/images/M/MV5BMTY1NTI0ODUyOF5BMl5BanBnXkFtZTgwNTEyNjQ0MDE@._V1_SX300.jpg"

5:
"Genre": "Drama, Sport",
"Director": "Sylvester Stallone",
"Runtime": "91 min"

6:
"Title": "Willy Wonka & the Chocolate Factory",
"Year": "1971"


POKE API:

1: https://pokeapi.co/api/v2/pokemon/pikachu

2: 21

3: "name": "mewtwo"

4: 
"move": {
                "name": "mega-punch",
                "url": "https://pokeapi.co/api/v2/move/5/"
},

"move": {
                "name": "fire-punch",
                "url": "https://pokeapi.co/api/v2/move/7/"
},

"move": {
                "name": "thunder-punch",
                "url": "https://pokeapi.co/api/v2/move/9/"
}

5:
"weight": 69,
"height": 7

6:

